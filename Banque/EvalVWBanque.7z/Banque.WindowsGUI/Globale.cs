﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Banque.BOL;

namespace Banque.WindowsGUI
{
    static class Globale
    {
        public static Client Client { get; set; }
    }
}
