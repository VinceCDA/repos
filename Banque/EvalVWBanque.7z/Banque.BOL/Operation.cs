
namespace Banque.BOL
{
    using System;
    using System.Collections.Generic;
    
    public partial class Operation
    {
       
        public Operation()
        {
           
        }
    
        public string CodeOperation { get; set; }
        public string DesignationOperation { get; set; }
    
    }
}
